package com.example.borrowingmanagementapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;


public class DBUtil {
    private DBOpenHelper dbOpenHelper;
    //private Context mContext;

    public DBUtil(Context context) {
        //mContext = context;
        dbOpenHelper = new DBOpenHelper(context);
    }

    /*
    private SQLiteDatabase getDB() {
        dbOpenHelper = new DBOpenHelper(mContext);
        SQLiteDatabase database = dbOpenHelper.getReadableDatabase();
    }

     */

    public List<DataObject> getDBAllData() {
        //getDB();
        //dbOpenHelper = new DBOpenHelper(context);

        List<DataObject> dataObjects = new ArrayList<>();
        SQLiteDatabase database = dbOpenHelper.getReadableDatabase();
        Cursor cursor = null;

        try {
            cursor = database.query(dbOpenHelper.TABLE_NAME, null, null, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                do {
                    DataObject dataObject = new DataObject();
                    dataObject.setItem(cursor.getString(cursor.getColumnIndexOrThrow(DBOpenHelper.COLUMN_ITEM)));
                    dataObject.setSerial(cursor.getString(cursor.getColumnIndexOrThrow(DBOpenHelper.COLUMN_SERIAL)));
                    dataObject.setBorrower(cursor.getString(cursor.getColumnIndexOrThrow(DBOpenHelper.COLUMN_BORROWER)));
                    dataObject.setBorrowDate(cursor.getString(cursor.getColumnIndexOrThrow(DBOpenHelper.COLUMN_BORROW_DATE)));
                    dataObject.setScheduleReturnDate(cursor.getString(cursor.getColumnIndexOrThrow(DBOpenHelper.COLUMN_SCHEDULE_RETURN_DATE)));
                    dataObject.setLocation(cursor.getString(cursor.getColumnIndexOrThrow(DBOpenHelper.COLUMN_LOCATION)));
                    dataObject.setReturnedDate(cursor.getString(cursor.getColumnIndexOrThrow(DBOpenHelper.COLUMN_RETURNED_DATE)));
                    dataObject.setCustomer(cursor.getString(cursor.getColumnIndexOrThrow(DBOpenHelper.COLUMN_CUSTOMER)));
                    dataObjects.add(dataObject);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (cursor != null) {
            cursor.close();
        }

        database.close();
        return dataObjects;
    }

    public List<DataObject> getDBData(String serial) {
        List<DataObject> dataObjects = new ArrayList<>();
        SQLiteDatabase db = dbOpenHelper.getReadableDatabase();
        String[] columns = {
                DBOpenHelper.COLUMN_SERIAL,
                DBOpenHelper.COLUMN_ITEM,
                DBOpenHelper.COLUMN_BORROWER,
                DBOpenHelper.COLUMN_BORROW_DATE,
                DBOpenHelper.COLUMN_SCHEDULE_RETURN_DATE,
                DBOpenHelper.COLUMN_LOCATION,
                DBOpenHelper.COLUMN_RETURNED_DATE,
                DBOpenHelper.COLUMN_CUSTOMER
        };
        String selection = DBOpenHelper.COLUMN_SERIAL + " = ?";
        String[] selectionArgs = {serial};
        Cursor cursor = null;

        try {
            cursor = db.query(DBOpenHelper.TABLE_NAME, columns, selection, selectionArgs, null, null, null);

            if (cursor != null && cursor.moveToFirst()) {
                do {
                    DataObject dataObject = new DataObject();
                    dataObject.setSerial(cursor.getString(cursor.getColumnIndexOrThrow(DBOpenHelper.COLUMN_SERIAL)));
                    dataObject.setItem(cursor.getString(cursor.getColumnIndexOrThrow(DBOpenHelper.COLUMN_ITEM)));
                    dataObject.setBorrower(cursor.getString(cursor.getColumnIndexOrThrow(DBOpenHelper.COLUMN_BORROWER)));
                    dataObject.setBorrowDate(cursor.getString(cursor.getColumnIndexOrThrow(DBOpenHelper.COLUMN_BORROW_DATE)));
                    dataObject.setScheduleReturnDate(cursor.getString(cursor.getColumnIndexOrThrow(DBOpenHelper.COLUMN_SCHEDULE_RETURN_DATE)));
                    dataObject.setLocation(cursor.getString(cursor.getColumnIndexOrThrow(DBOpenHelper.COLUMN_LOCATION)));
                    dataObject.setReturnedDate(cursor.getString(cursor.getColumnIndexOrThrow(DBOpenHelper.COLUMN_RETURNED_DATE)));
                    dataObject.setCustomer(cursor.getString(cursor.getColumnIndexOrThrow(DBOpenHelper.COLUMN_CUSTOMER)));

                    dataObjects.add(dataObject);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            db.close();
        }

        return dataObjects;
    }

    public void updateDBData(String serial, DataObject newData) {
        SQLiteDatabase db = dbOpenHelper.getWritableDatabase();

        // 新しいデータをContentValuesにセット
        ContentValues values = new ContentValues();
        values.put(DBOpenHelper.COLUMN_ITEM, newData.getItem());
        values.put(DBOpenHelper.COLUMN_BORROWER, newData.getBorrower());
        values.put(DBOpenHelper.COLUMN_BORROW_DATE, newData.getBorrowDate());
        values.put(DBOpenHelper.COLUMN_SCHEDULE_RETURN_DATE, newData.getScheduleReturnDate());
        values.put(DBOpenHelper.COLUMN_LOCATION, newData.getLocation());
        values.put(DBOpenHelper.COLUMN_RETURNED_DATE, newData.getReturnedDate());
        values.put(DBOpenHelper.COLUMN_CUSTOMER, newData.getCustomer());

        // データを更新
        db.update(DBOpenHelper.TABLE_NAME, values, DBOpenHelper.COLUMN_SERIAL + " = ?", new String[]{serial});

        // データベースを閉じる
        db.close();
    }

    public boolean insertDBData(DataObject newData) {
        SQLiteDatabase db = dbOpenHelper.getWritableDatabase();

        // 既に同じシリアル番号が登録されているかチェック
        if (isAlreadyRegistered(db, newData.getSerial())) {
            db.close();
            return false; // 既に登録されている場合はfalseを返す
        }

        ContentValues values = new ContentValues();
        values.put(DBOpenHelper.COLUMN_SERIAL, newData.getSerial());
        values.put(DBOpenHelper.COLUMN_ITEM, newData.getItem());
        values.put(DBOpenHelper.COLUMN_BORROWER, newData.getBorrower());
        values.put(DBOpenHelper.COLUMN_BORROW_DATE, newData.getBorrowDate());
        values.put(DBOpenHelper.COLUMN_SCHEDULE_RETURN_DATE, newData.getScheduleReturnDate());
        values.put(DBOpenHelper.COLUMN_LOCATION, newData.getLocation());
        values.put(DBOpenHelper.COLUMN_RETURNED_DATE, newData.getReturnedDate());
        values.put(DBOpenHelper.COLUMN_CUSTOMER, newData.getCustomer());

        // データを挿入
        db.insert(DBOpenHelper.TABLE_NAME, null, values);
        db.close();
        return true; // 正常に追加された場合はtrueを返す
    }


    private boolean isAlreadyRegistered(SQLiteDatabase db, String serial) {
        String query = "SELECT * FROM " + DBOpenHelper.TABLE_NAME + " WHERE " + DBOpenHelper.COLUMN_SERIAL + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{serial});
        boolean isRegistered = cursor.getCount() > 0;
        cursor.close();
        return isRegistered;
    }

    public void deleteDBData(String serial) {
        SQLiteDatabase db = dbOpenHelper.getWritableDatabase();
        db.delete(DBOpenHelper.TABLE_NAME, DBOpenHelper.COLUMN_SERIAL + " = ?", new String[]{serial});
        db.close();
    }

}
