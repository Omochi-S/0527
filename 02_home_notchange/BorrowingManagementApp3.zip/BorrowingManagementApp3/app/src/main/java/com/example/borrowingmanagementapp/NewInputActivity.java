package com.example.borrowingmanagementapp;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.borrowingmanagementapp.view.InputDateView;
import com.example.borrowingmanagementapp.view.InputTextView;

/**
 * NewInputActivityクラス
 * 「新規借用」画面
 */
public class NewInputActivity extends AppCompatActivity  implements View.OnClickListener {
    private static final String LOG_TAG = NewInputActivity.class.getSimpleName();

    //入力状況
    private static final String REQUIRED = "required";
    private static final String OPTIONAL = "optional";

    private static final String INPUT_TYPE_HALF = "half";
    private static final String INPUT_TYPE_FULL = "full";

    private static final String INPUT_TYPE_INVALID = "invalid";


    private static final int KEY = 0;
    private static final int VIEW_ID = 1;
    private static final int CONDITION = 2;

    private static final int INPUT_TYPE = 3;

    private static final String[][] INPUT_DATA = {
            {TemporaryStorage.KEY_ITEM, "input_text_new_input_item", REQUIRED, INPUT_TYPE_FULL},
            {TemporaryStorage.KEY_SERIAL, "input_text_new_input_serial", REQUIRED, INPUT_TYPE_HALF},
            {TemporaryStorage.KEY_BORROWER, "input_text_new_input_borrower", REQUIRED, INPUT_TYPE_FULL},
            {TemporaryStorage.KEY_BORROW_DATE, "input_date_new_input_borrow", REQUIRED, INPUT_TYPE_INVALID},
            {TemporaryStorage.KEY_SCHEDULE_RETURN_DATE, "input_date_new_input_schedule_return", REQUIRED, INPUT_TYPE_INVALID},
            {TemporaryStorage.KEY_LOCATION, "input_text_new_input_location", REQUIRED, INPUT_TYPE_FULL},
            {TemporaryStorage.KEY_RETURNED_DATE, "input_date_new_input_returned", OPTIONAL, INPUT_TYPE_INVALID},
            {TemporaryStorage.KEY_CUSTOMER, "input_text_new_input_customer", REQUIRED, INPUT_TYPE_FULL}
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //ログを出力
        Log.i(LOG_TAG, "onCreate");
        super.onCreate(savedInstanceState);

        //レイアウトをセット
        setContentView(R.layout.activity_new_input);
        // レイアウトの調整を行う
        adjustLayout();
    }

    @Override
    protected void onStart() {
        super.onStart();
        // 一時保存データを削除
        TemporaryStorage.getInstance().clearAllData();
    }

    @Override
    public void onClick(View v) {
        Log.d(LOG_TAG, "Button clicked with ID: " + v.getId());

        // クリックされたビューがnullでないかを確認
        if (v == null) {
            Log.w(LOG_TAG, "Clicked view is null");
            return;
        }

        // 適切なインテントを作成
        if (v.getId() == R.id.button_new_input_to_new_check) {
            // 必須項目が全て入力されているかどうかを確認
            if (areRequiredFieldsFilled()) {
                if(inputChecker()) {
                    Intent intent = new Intent(getApplicationContext(), NewCheckActivity.class);
                    saveDataToTemporaryStorage();
                    Log.i(LOG_TAG, "Navigating to NewCheckActivity");
                    // インテントがnullでない場合は、アクティビティを起動
                    if(intent != null) {
                        startActivity(intent);
                    } else {
                        Log.e(LOG_TAG, "Intent is null for view ID: " + v.getId());
                    }
                    Log.i(LOG_TAG, "Navigating to NewCheckActivity");
                } else {
                    // 必須項目が全て入力されていない場合はToastを表示して処理を中断
                    Toast.makeText(getApplicationContext(), R.string.warning_incorrect_entered, Toast.LENGTH_SHORT).show();
                }
            } else {
                // 必須項目が全て入力されていない場合はToastを表示して処理を中断
                Context context = getApplicationContext();
                Toast toast = Toast.makeText(context, R.string.warning_not_entered, Toast.LENGTH_LONG);
                toast.show();
            }
        }
    }

    /**
     * adjustLayoutメソッド
     * レイアウトの調整
     */
    private void adjustLayout() {

        //ヘッダーの設定
        TextView titleTextView = findViewById(R.id.textview_new_input_title);
        titleTextView.setText(R.string.title_new_input);

        // 入力画面遷移ボタンの調整
        Button newCheckButton = findViewById(R.id.button_new_input_to_new_check);
        newCheckButton.setText(R.string.button_registration);
        newCheckButton.setOnClickListener(this);
    }


    /**
     * areRequiredFieldsFilledメソッド
     * 必須項目がすべて入力されているかどうかをチェック
     * @return 必須項目がすべて入力されている場合はtrue、そうでない場合はfalse
     */
    private boolean areRequiredFieldsFilled() {
        for (String[] data : INPUT_DATA) {
            if (data[CONDITION].equals(REQUIRED)) {
                // 入力項目のビューIDを取得
                int viewId = getResources().getIdentifier(data[VIEW_ID], "id", getPackageName());
                // ビューが見つからない場合はログを出力して次のループに進む
                if (viewId == 0) {
                    Log.e(LOG_TAG, "View not found for ID: " + data[VIEW_ID]);
                    continue;
                }
                // ビューを取得
                View inputView = findViewById(viewId);
                // 入力値の初期化
                String value = "";
                // ビューの種類に応じて値を取得
                if (inputView instanceof InputTextView) {
                    value = ((InputTextView) inputView).getEditTextValue();
                } else if (inputView instanceof InputDateView) {
                    value = ((InputDateView) inputView).getDateTextValue();
                }
                // 必須項目が空であればfalseを返す
                if (value.isEmpty()) {
                    return false;
                }
            }
        }
        // 必須項目が全て入力されている場合はtrueを返す
        return true;
    }

    /**
     * saveDataToTemporaryStorageメソッド
     * 入力されたデータを一時的なストレージに保存
     * 入力されたデータは、品名、シリアル番号、借用者、借用日、返却予定日、使用場所、返却日、顧客名の各項目から取得
     */
    private void saveDataToTemporaryStorage() {
        for (String[] data : INPUT_DATA) {
            // 入力項目のビューIDを取得
            int viewId = getResources().getIdentifier(data[VIEW_ID], "id", getPackageName());
            // ビューが見つからない場合はログを出力して次のループに進む
            if (viewId == 0) {
                Log.e(LOG_TAG, "View not found for ID: " + data[VIEW_ID]);
                continue;
            }
            // ビューを取得
            View inputView = findViewById(viewId);
            // 入力値の初期化
            String value = "";
            // ビューの種類に応じて値を取得
            if (inputView instanceof InputTextView) {
                value = ((InputTextView) inputView).getEditTextValue();
            } else if (inputView instanceof InputDateView) {
                value = ((InputDateView) inputView).getDateTextValue();
            }
            // 取得した値をログに出力
            Log.d(LOG_TAG, inputView.getContentDescription() + " value retrieved: " + value);
            // 取得した値を一時的なストレージに保存
            TemporaryStorage.getInstance().saveData(data[KEY], value);
        }
    }

    private boolean inputChecker() {
        boolean isCorrect = true;
        for (String[] data : INPUT_DATA) {
            boolean isInputCorrect = true;
            if (data[INPUT_TYPE] == INPUT_TYPE_INVALID) {
                continue;
            }

            // 入力項目のビューIDを取得
            int viewId = getResources().getIdentifier(data[VIEW_ID], "id", getPackageName());
            // ビューが見つからない場合はログを出力して次のループに進む
            if (viewId == 0) {
                Log.e(LOG_TAG, "View not found for ID: " + data[VIEW_ID]);
                continue;
            }
            // ビューを取得
            View inputView = findViewById(viewId);
            // 入力値の初期化
            String value = "";

            if (inputView instanceof InputTextView) {
                ((InputTextView) inputView).setEditTextBackgroundColor(R.color.white);
                value = ((InputTextView) inputView).getEditTextValue();
                //半角入力
                if (data[INPUT_TYPE] == INPUT_TYPE_HALF) {
                    isInputCorrect = InputTextView.isValidInput(value, InputTextView.INPUT_TYPE_HALF_WIDTH);
                } else if (data[INPUT_TYPE] == INPUT_TYPE_FULL) {
                    isInputCorrect = InputTextView.isValidInput(value, InputTextView.INPUT_TYPE_FULL_WIDTH);
                }
                if(!(isInputCorrect)) {
                    ((InputTextView) inputView).setEditTextBackgroundColor(R.color.yellow);
                    isCorrect = false;
                }
            }
            // 取得した値をログに出力
            Log.d(LOG_TAG, inputView.getContentDescription() + " value retrieved: " + value);
        }
        return isCorrect;
    }
}
