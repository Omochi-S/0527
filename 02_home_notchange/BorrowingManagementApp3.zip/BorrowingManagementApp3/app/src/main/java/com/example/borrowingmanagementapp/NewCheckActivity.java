package com.example.borrowingmanagementapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.HashMap;
import java.util.Map;

/**
 * NewCheckActivityクラス
 * 「新規借用確認」画面
 */
public class NewCheckActivity  extends AppCompatActivity implements View.OnClickListener {

    private static final String LOG_TAG = NewCheckActivity.class.getSimpleName();

    private static final Map<String, Integer> DATA_LABEL = new HashMap<String, Integer>() {{
        put(TemporaryStorage.KEY_ITEM, R.string.label_item);
        put(TemporaryStorage.KEY_SERIAL, R.string.label_serial);
        put(TemporaryStorage.KEY_BORROWER, R.string.label_borrower);
        put(TemporaryStorage.KEY_BORROW_DATE, R.string.label_borrow_date);
        put(TemporaryStorage.KEY_SCHEDULE_RETURN_DATE, R.string.label_schedule_return_date);
        put(TemporaryStorage.KEY_LOCATION, R.string.label_location);
        put(TemporaryStorage.KEY_RETURNED_DATE, R.string.label_returned_date);
        put(TemporaryStorage.KEY_CUSTOMER, R.string.label_customer);
    }};

    private static final Map<String, String> DATA_VALUE = new HashMap<String, String>() {{
        put(TemporaryStorage.KEY_ITEM, ""); // 値は初期値として空文字列を入れておきます
        put(TemporaryStorage.KEY_SERIAL, "");
        put(TemporaryStorage.KEY_BORROWER, "");
        put(TemporaryStorage.KEY_BORROW_DATE, "");
        put(TemporaryStorage.KEY_SCHEDULE_RETURN_DATE, "");
        put(TemporaryStorage.KEY_LOCATION, "");
        put(TemporaryStorage.KEY_RETURNED_DATE, "");
        put(TemporaryStorage.KEY_CUSTOMER, "");
    }};

    // 表示する順番のキーを格納する配列
    private static final String[] DISPLAY_ORDER = {
            TemporaryStorage.KEY_ITEM,
            TemporaryStorage.KEY_SERIAL,
            TemporaryStorage.KEY_BORROWER,
            TemporaryStorage.KEY_BORROW_DATE,
            TemporaryStorage.KEY_SCHEDULE_RETURN_DATE,
            TemporaryStorage.KEY_LOCATION,
            TemporaryStorage.KEY_RETURNED_DATE,
            TemporaryStorage.KEY_CUSTOMER
    };



    @Override
    /**
     * onCreateメソッド
     * アクティビティが初めて作成されたときに呼び出される
     * @param savedInstanceState アクティビティの前回の状態を保存したバンドル
     */
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i(LOG_TAG, "onCreate called");
        // レイアウトをセット
        setContentView(R.layout.activity_new_check);
        // レイアウトの調整
        adjustLayout();
    }

    /**
     * adjustLayoutメソッド
     * レイアウトの調整を行います。
     */
    private void adjustLayout() {
        //タイトルの設定
        TextView titleTextView = findViewById(R.id.textview_new_check_title);
        titleTextView.setText(R.string.title_new_check);

        // 画面遷移ボタンの設定
        Button listButton = findViewById(R.id.button_new_check_ng);
        listButton.setText(R.string.button_ng);
        listButton.setOnClickListener(this);

        Button newInputButton = findViewById(R.id.button_new_check_ok);
        newInputButton.setText(R.string.button_ok);
        newInputButton.setOnClickListener(this);

        displayDataFromTemporaryStorage();
    }

    /**
     * TemporaryStorageからデータを取得してTextViewに表示するメソッド
     */
    private void displayDataFromTemporaryStorage() {
        // TextViewを取得
        TextView dataTextView = findViewById(R.id.textview_display_data);

        // TemporaryStorageのインスタンスを取得
        TemporaryStorage temporaryStorage = TemporaryStorage.getInstance();

        // すべてのデータを取得してTextViewに表示
        StringBuilder displayTextBuilder = new StringBuilder();
        for (String key : temporaryStorage.getAllKeys()) {
            String value = temporaryStorage.getData(key);
            DATA_VALUE.put(key, value);
        }

        for (String key : DISPLAY_ORDER) {
            int labelResourceId = DATA_LABEL.get(key); // 対応するラベルのリソースIDを取得
            String labelText = getString(labelResourceId); // リソースIDからラベルのテキストを取得
            String value = DATA_VALUE.get(key);

            if(key == TemporaryStorage.KEY_ITEM) {
                displayTextBuilder.append(value).append("\n");
            } else {
                displayTextBuilder.append("　").append(labelText).append("　：　").append(value).append("\n");
            }
        }

        // TextViewに表示
        dataTextView.setText(displayTextBuilder.toString());
    }

    @Override
    /**
     * onClickメソッド
     * ボタンがクリックされたときに呼び出される
     * @param v クリックされたビュー
     */
    public void onClick(View v) {
        Log.d(LOG_TAG, "Button clicked with ID: " + v.getId());
        Intent intent = null;

        // クリックされたビューがnullでないかを確認
        if (v == null) {
            Log.w(LOG_TAG, "Clicked view is null");
            return;
        }

        // クリックされたビューによって適切なインテントを作成
        if (v.getId() == R.id.button_new_check_ok) {
            //DBデータ登録
            insertDBData();
        }
        //ストレージデータ削除
        TemporaryStorage.getInstance().clearAllData();
        finish();
    }

    /**
     * insertDBDataメソッド
     * TemporaryStorageに保存されているデータをデータベースに追加する
     */
    private void insertDBData() {
        // TemporaryStorageのインスタンスを取得
        TemporaryStorage temporaryStorage = TemporaryStorage.getInstance();

        // データをTemporaryStorageから取得
        String serial = temporaryStorage.getData(TemporaryStorage.KEY_SERIAL);
        String item = temporaryStorage.getData(TemporaryStorage.KEY_ITEM);
        String borrower = temporaryStorage.getData(TemporaryStorage.KEY_BORROWER);
        String borrowDate = temporaryStorage.getData(TemporaryStorage.KEY_BORROW_DATE);
        String scheduleReturnDate = temporaryStorage.getData(TemporaryStorage.KEY_SCHEDULE_RETURN_DATE);
        String location = temporaryStorage.getData(TemporaryStorage.KEY_LOCATION);
        String returnedDate = temporaryStorage.getData(TemporaryStorage.KEY_RETURNED_DATE);
        String customer = temporaryStorage.getData(TemporaryStorage.KEY_CUSTOMER);

        // DBOpenHelperのインスタンスを取得
        DBUtil dbUtil = new DBUtil(this);

        // 新しいDataObjectを作成
        DataObject newData = new DataObject();
        newData.setSerial(serial);
        newData.setItem(item);
        newData.setBorrower(borrower);
        newData.setBorrowDate(borrowDate);
        newData.setScheduleReturnDate(scheduleReturnDate);
        newData.setLocation(location);
        newData.setReturnedDate(returnedDate);
        newData.setCustomer(customer);

        // データを追加
        boolean isAdditional = dbUtil.insertDBData(newData);

        if (isAdditional) {
            Toast.makeText(this, R.string.toast_registration_complete, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, R.string.toast_already_registered, Toast.LENGTH_SHORT).show();
        }
    }

}
