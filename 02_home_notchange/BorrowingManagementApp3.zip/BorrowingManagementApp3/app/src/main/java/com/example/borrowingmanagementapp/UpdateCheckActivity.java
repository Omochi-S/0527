package com.example.borrowingmanagementapp;

import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.HashMap;
import java.util.Map;

/**
 * UpdateCheckActivityクラス
 * 「更新確認」画面
 */
public class UpdateCheckActivity  extends AppCompatActivity implements View.OnClickListener {

    private static final String LOG_TAG = UpdateCheckActivity.class.getSimpleName();

    private static final Map<String, Integer> DATA_LABEL = new HashMap<String, Integer>() {{
        put(TemporaryStorage.KEY_ITEM, R.string.label_item);
        put(TemporaryStorage.KEY_SERIAL, R.string.label_serial);
        put(TemporaryStorage.KEY_BORROWER, R.string.label_borrower);
        put(TemporaryStorage.KEY_BORROW_DATE, R.string.label_borrow_date);
        put(TemporaryStorage.KEY_SCHEDULE_RETURN_DATE, R.string.label_schedule_return_date);
        put(TemporaryStorage.KEY_LOCATION, R.string.label_location);
        put(TemporaryStorage.KEY_RETURNED_DATE, R.string.label_returned_date);
        put(TemporaryStorage.KEY_CUSTOMER, R.string.label_customer);
    }};

    private static final Map<String, String> DATA_VALUE = new HashMap<String, String>() {{
        put(TemporaryStorage.KEY_ITEM, ""); // 値は初期値として空文字列を入れておきます
        put(TemporaryStorage.KEY_SERIAL, "");
        put(TemporaryStorage.KEY_BORROWER, "");
        put(TemporaryStorage.KEY_BORROW_DATE, "");
        put(TemporaryStorage.KEY_SCHEDULE_RETURN_DATE, "");
        put(TemporaryStorage.KEY_LOCATION, "");
        put(TemporaryStorage.KEY_RETURNED_DATE, "");
        put(TemporaryStorage.KEY_CUSTOMER, "");
    }};

    // 表示する順番のキーを格納する配列
    private static final String[] DISPLAY_ORDER = {
            TemporaryStorage.KEY_ITEM,
            TemporaryStorage.KEY_SERIAL,
            TemporaryStorage.KEY_BORROWER,
            TemporaryStorage.KEY_BORROW_DATE,
            TemporaryStorage.KEY_SCHEDULE_RETURN_DATE,
            TemporaryStorage.KEY_LOCATION,
            TemporaryStorage.KEY_RETURNED_DATE,
            TemporaryStorage.KEY_CUSTOMER
    };

    @Override
    /**
     * onCreateメソッド
     * アクティビティが初めて作成されたときに呼び出される
     * @param savedInstanceState アクティビティの前回の状態を保存したバンドル
     */
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i(LOG_TAG, "onCreate called");
        // レイアウトをセット
        setContentView(R.layout.activity_update_check);
        // レイアウトの調整
        adjustLayout();
    }

    /**
     * adjustLayoutメソッド
     * レイアウトの調整を行います。
     */
    private void adjustLayout() {
        //タイトルの設定
        TextView titleTextView = findViewById(R.id.textview_update_check_title);
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("action")) {
            String action = intent.getStringExtra("action");
            if ("delete".equals(action)) {
                // deleteアクションの場合はDB削除処理を行う
                titleTextView.setText(R.string.title_delete_check);
            } else if ("update".equals(action)) {
                // updateアクションの場合はDB更新処理を行う
                titleTextView.setText(R.string.title_update_check);
            }
        }

        // 画面遷移ボタンの設定
        Button listButton = findViewById(R.id.button_update_check_ng);
        listButton.setText(R.string.button_ng);
        listButton.setOnClickListener(this);

        Button newInputButton = findViewById(R.id.button_update_check_ok);
        newInputButton.setText(R.string.button_ok);
        newInputButton.setOnClickListener(this);

        displayDataFromTemporaryStorage();
    }

    /**
     * TemporaryStorageからデータを取得してTextViewに表示するメソッド
     */
    private void displayDataFromTemporaryStorage() {
        // TextViewを取得
        TextView dataTextView = findViewById(R.id.textview_display_data);

        // TemporaryStorageのインスタンスを取得
        TemporaryStorage temporaryStorage = TemporaryStorage.getInstance();

        // すべてのデータを取得してTextViewに表示
        StringBuilder displayTextBuilder = new StringBuilder();
        for (String key : temporaryStorage.getAllKeys()) {
            String value = temporaryStorage.getData(key);
            DATA_VALUE.put(key, value);
        }

        for (String key : DISPLAY_ORDER) {
            int labelResourceId = DATA_LABEL.get(key); // 対応するラベルのリソースIDを取得
            String labelText = getString(labelResourceId); // リソースIDからラベルのテキストを取得
            String value = DATA_VALUE.get(key);

            if(key == TemporaryStorage.KEY_ITEM) {
                displayTextBuilder.append(value).append("\n");
            } else {
                displayTextBuilder.append("　").append(labelText).append("　：　").append(value).append("\n");
            }
        }

        // TextViewに表示
        dataTextView.setText(displayTextBuilder.toString());
    }

    @Override
    public void onClick(View v) {
        Log.d(LOG_TAG, "Button clicked with ID: " + v.getId());
        Intent intent = null;

        // クリックされたビューがnullでないかを確認
        if (v == null) {
            Log.w(LOG_TAG, "Clicked view is null");
            return;
        }
        v.getId();

        // クリックされたビューによって適切なインテントを作成
        if (v.getId() == R.id.button_update_check_ok) {
            // 受け取ったIntentからアクションを取得
            intent = getIntent();
            if (intent != null && intent.hasExtra("action")) {
                String action = intent.getStringExtra("action");

                if ("delete".equals(action)) {
                    // deleteアクションの場合はDB削除処理を行う
                    deleteData();
                } else if ("update".equals(action)) {
                    // updateアクションの場合はDB更新処理を行う
                    updateData();
                }

            }
            //ストレージデータ削除
            TemporaryStorage.getInstance().clearAllData();

            Intent intent2 = new Intent(getApplicationContext(), ListActivity.class);
            startActivity(intent2);
            finish();
        } else if(v.getId() == R.id.button_update_check_ng) {
            //ストレージデータ削除
            TemporaryStorage.getInstance().clearAllData();
            finish();
        }
    }

    /**
     * deleteDataメソッド
     * TemporaryStorageに保存されているデータをデータベースから削除する
     */
    /**
     * deleteDataメソッド
     * TemporaryStorageに保存されているデータをデータベースから削除する
     */
    private void deleteData() {
        // TemporaryStorageのインスタンスを取得
        TemporaryStorage temporaryStorage = TemporaryStorage.getInstance();

        // シリアル番号を取得
        String serial = temporaryStorage.getData(TemporaryStorage.KEY_SERIAL);

        // DBUtilのインスタンスを取得
        DBUtil dbUtil = new DBUtil(getApplicationContext());

        // データを削除
        dbUtil.deleteDBData(serial);

        Toast.makeText(this, R.string.toast_data_deleted, Toast.LENGTH_SHORT).show();
    }


    /**
     * updateDataメソッド
     * TemporaryStorageに保存されているデータをデータベースで更新する
     */
    private void updateData() {
        // TemporaryStorageのインスタンスを取得
        TemporaryStorage temporaryStorage = TemporaryStorage.getInstance();

        // データをTemporaryStorageから取得
        String serial = temporaryStorage.getData(TemporaryStorage.KEY_SERIAL);
        String item = temporaryStorage.getData(TemporaryStorage.KEY_ITEM);
        String borrower = temporaryStorage.getData(TemporaryStorage.KEY_BORROWER);
        String borrowDate = temporaryStorage.getData(TemporaryStorage.KEY_BORROW_DATE);
        String scheduleReturnDate = temporaryStorage.getData(TemporaryStorage.KEY_SCHEDULE_RETURN_DATE);
        String location = temporaryStorage.getData(TemporaryStorage.KEY_LOCATION);
        String returnedDate = temporaryStorage.getData(TemporaryStorage.KEY_RETURNED_DATE);
        String customer = temporaryStorage.getData(TemporaryStorage.KEY_CUSTOMER);

        // 新しいデータをDataObjectにセット
        DataObject newDataObject = new DataObject();
        newDataObject.setItem(item);
        newDataObject.setBorrower(borrower);
        newDataObject.setBorrowDate(borrowDate);
        newDataObject.setScheduleReturnDate(scheduleReturnDate);
        newDataObject.setLocation(location);
        newDataObject.setReturnedDate(returnedDate);
        newDataObject.setCustomer(customer);

        // DBUtilのインスタンスを取得
        DBUtil dbUtil = new DBUtil(this);

        // データを更新
        dbUtil.updateDBData(serial, newDataObject);

        Toast.makeText(this, R.string.toast_data_updated, Toast.LENGTH_SHORT).show();
    }
}
