package com.example.borrowingmanagementapp.view;
//TODO:入力制限が未設定
import android.content.Context;
import android.content.res.TypedArray;
import android.text.InputFilter;
import android.text.Spanned;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.example.borrowingmanagementapp.R;

import java.util.regex.Pattern;

/**
 * InputTextViewクラス
 * Textを入力するためのカスタムビュー
 */
public class InputTextView extends LinearLayout {

    private static final String LOG_TAG = InputTextView.class.getSimpleName();

    private TextView textView;
    private EditText editText;
    private TextView warningTextView;


    // 入力タイプの定数
    public static final int INPUT_TYPE_HALF_WIDTH = 0;
    public static final int INPUT_TYPE_FULL_WIDTH = 1;
    private int inputType;

    /**
     * コンストラクタ
     * @param context コンテキスト
     */
    public InputTextView(Context context) {
        super(context);
        init(context, null);
    }

    /**
     * コンストラクタ
     * @param context コンテキスト
     * @param attrs 属性セット
     */
    public InputTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs);
    }

    /**
     * コンストラクタ
     * @param context コンテキスト
     * @param attrs 属性セット
     * @param defStyleAttr デフォルトスタイル
     */
    public InputTextView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs);
    }

    /**
     * initメソッド
     * カスタムビューを初期化
     * @param context コンテキスト
     * @param attrs 属性セット
     */
    private void init(Context context, AttributeSet attrs) {
        LayoutInflater.from(context).inflate(R.layout.view_input_text, this, true);

        textView = findViewById(R.id.textview_input_text_item);
        editText = findViewById(R.id.edittext_input_text_entry);
        warningTextView = findViewById(R.id.textview_input_text_warning);

        Log.d(LOG_TAG, "Views initialized");

        // XMLで指定された属性を読み取り、TextViewとEditTextに適用
        if (attrs != null) {
            TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.InputTextView);

            // TextViewのテキストを設定
            String textViewText = a.getString(R.styleable.InputTextView_textViewInputTextItem);
            if (textViewText != null) {
                textView.setText(textViewText);
                Log.d(LOG_TAG, "TextView text set from XML attributes: " + textViewText);
            }

            // EditTextのヒントを設定
            String editTextHint = a.getString(R.styleable.InputTextView_editTextInputTextHint);
            if (editTextHint != null) {
                editText.setHint(editTextHint);
                Log.d(LOG_TAG, "EditText hint set from XML attributes: " + editTextHint);
            }

            // 警告用TextViewのテキストを設定
            String warningTextViewText = a.getString(R.styleable.InputTextView_textViewInputTextWarning);
            if (warningTextViewText != null) {
                warningTextView.setText(warningTextViewText);
                Log.d(LOG_TAG, "Warning TextView text set from XML attributes: " + warningTextViewText);
            }
            a.recycle();
        }
    }

    /**
     * setTextViewTextメソッド
     * TextViewのテキストを設定
     * @param text テキスト
     */
    public void setTextViewText(String text) {
        textView.setText(text);
        Log.d(LOG_TAG, "TextView text set: " + text);
    }

    /**
     * setEditTextHintメソッド
     * EditTextのヒントを設定
     * @param hint ヒント
     */
    public void setEditTextHint(String hint) {
        editText.setHint(hint);
        Log.d(LOG_TAG, "EditText hint set: " + hint);
    }

    /**
     * setWarningTextViewTextメソッド
     * 警告用TextViewのテキストを設定
     * @param text テキスト
     */
    public void setWarningTextViewText(String text) {
        warningTextView.setText(text);
        Log.d(LOG_TAG, "Warning TextView text set: " + text);
    }

    /**
     * getEditTextValueメソッド
     * EditTextに入力されたテキストを取得
     * @return 入力されたテキスト
     */
    public String getEditTextValue() {
        String value = editText.getText().toString();
        Log.d(LOG_TAG, "EditText value retrieved: " + value);
        return value;
    }

    /**
     * EditText の値を設定します。
     * @param value EditText に設定する値
     */
    public void setEditTextValue(String value) {
        editText.setText(value);
    }



    /**
     * setEnabledメソッド
     * EditTextの有効/無効を設定
     * @param enabled trueなら有効、falseなら無効
     */
    public void setEnabledEditText(boolean enabled) {
        editText.setEnabled(enabled);
        Log.d(LOG_TAG, "EditText enabled set to: " + enabled);
    }

    /**
     * 入力が適切かを確認するメソッド
     * @param str 確認する文字列
     * @param inputType 入力タイプ（INPUT_TYPE_HALF_WIDTH: 半角英数字、INPUT_TYPE_FULL_WIDTH: 全角）
     * @return 適切な入力の場合はtrue、それ以外の場合はfalse
     */
    public static boolean isValidInput(String str, int inputType) {
        boolean isValid = false;

        if(inputType == INPUT_TYPE_HALF_WIDTH) {
            isValid = isHalfWidthAlphanumeric(str);
            Log.d(LOG_TAG, "Input validation for half-width alphanumeric: " + isValid);

        } else if (inputType == INPUT_TYPE_FULL_WIDTH) {
            isValid = isFullWidth(str);
            Log.d(LOG_TAG, "Input validation for full-width: " + isValid);
        }

        return isValid;
    }

    /**
     * 文字列が半角英数字であるかを確認するメソッド
     * @param str 確認する文字列
     * @return 半角英数字の場合はtrue、それ以外の場合はfalse
     */
    private static boolean isHalfWidthAlphanumeric(String str) {
        boolean isHalfWidthAlphanumeric = str.matches("[0-9a-zA-Z]+");
        Log.d(LOG_TAG, "Half-width alphanumeric check for '" + str + "': " + isHalfWidthAlphanumeric);
        return isHalfWidthAlphanumeric;
    }

    /**
     * 文字列が全角であるかを確認するメソッド
     * @param str 確認する文字列
     * @return 全角のみで構成されている場合はtrue、それ以外の場合はfalse
     */
    private static boolean isFullWidth(String str) {
        String fullWidthCharacterPattern = "[^\\x00-\\x7F｡-ﾟ0-9a-zA-Z]";
        return Pattern.compile(fullWidthCharacterPattern).matcher(str).find();
    }

    /**
     * EditTextの背景色を変更するメソッド
     * @param color 背景色
     */
    public void setEditTextBackgroundColor(int color) {
        editText.setBackgroundColor(getResources().getColor(color));
        Log.d(LOG_TAG, "EditText background color set: " + color);
    }
}
