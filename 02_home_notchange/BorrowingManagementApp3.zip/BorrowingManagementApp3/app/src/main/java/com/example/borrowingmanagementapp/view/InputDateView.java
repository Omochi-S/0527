package com.example.borrowingmanagementapp.view;
//TODO:完璧
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.example.borrowingmanagementapp.R;
import java.util.Calendar;
import java.util.Locale;

/**
 * InputDateViewクラス
 * 日付を入力するためのカスタムビュー
 */
public class InputDateView extends LinearLayout {

    private static final String LOG_TAG = InputDateView.class.getSimpleName();
    private TextView textView;
    private TextView dateTextView;

    /**
     * コンストラクタ
     * @param context コンテキスト
     */
    public InputDateView(Context context) {
        super(context);
        init(context, null);
    }

    /**
     * コンストラクタ
     * @param context コンテキスト
     * @param attrs 属性セット
     */
    public InputDateView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs);
    }

    /**
     * コンストラクタ
     * @param context コンテキスト
     * @param attrs 属性セット
     * @param defStyleAttr デフォルトスタイル
     */
    public InputDateView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs);
    }

    /**
     * initメソッド
     * カスタムビューを初期化
     * @param context コンテキスト
     * @param attrs 属性セット
     */
    private void init(Context context, AttributeSet attrs) {
        inflate(getContext(), R.layout.view_input_date, this);
        textView = findViewById(R.id.textview_input_date_item);
        dateTextView = findViewById(R.id.textview_input_date_entry);

        Log.d(LOG_TAG, "Views initialized");

        // XMLで指定された属性を読み取り、TextViewに適用
        if (attrs != null) {
            TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.InputDateView);
            // TextViewのテキストを設定
            String textViewText = a.getString(R.styleable.InputDateView_textViewInputDateItem);
            if (textViewText != null) {
                textView.setText(textViewText);
                Log.d(LOG_TAG, "TextView text set from XML attributes: " + textViewText);
            }
            a.recycle();
        }
        setInputDate();
    }

    /**
     * setTextViewTextメソッド
     * TextViewのテキストを設定
     * @param text テキスト
     */
    public void setDateTextViewText(String text) {
        dateTextView.setText(text);
        Log.d(LOG_TAG, "TextView date text set: " + text);
    }

    /**
     * setTextViewTextメソッド
     * TextViewのテキストを設定
     * @param text テキスト
     */
    public void setTextViewText(String text) {
        textView.setText(text);
        Log.d(LOG_TAG, "TextView text set: " + text);
    }

    /**
     * setInputDateメソッド
     * 日付の入力処理を設定
     * dateTextViewをクリックした際に、DatePickerDialogを表示
     */
    private void setInputDate() {
        dateTextView.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(LOG_TAG, "dateTextView clicked");
                showDatePickerDialog();
            }
        });
        Log.d(LOG_TAG, "Date input listener set");
    }

    /**
     * showDatePickerDialogメソッド
     * DatePickerDialogを表示
     * 日付が選択されると、その日付がdateTextViewに表示される
     */
    private void showDatePickerDialog() {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);

        Log.d(LOG_TAG, "Showing DatePickerDialog with current date: " + year + "/" + (month + 1) + "/" + dayOfMonth);

        DatePickerDialog datePickerDialog = new DatePickerDialog(getContext(),
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        String selectedDate = String.format(Locale.getDefault(), "%04d/%02d/%02d", year, month + 1, dayOfMonth);
                        dateTextView.setText(selectedDate);
                        dateTextView.setTextColor(Color.BLACK);
                        Log.d(LOG_TAG, "Selected date set to dateTextView: " + selectedDate);
                    }
                }, year, month, dayOfMonth);
        datePickerDialog.show();
    }

    /**
     * getDateTextメソッド
     * dateTextViewの文字列値を取得する
     * @return dateTextViewの文字列値
     */
    public String getDateTextValue() {
        String value = dateTextView.getText().toString();
        Log.d(LOG_TAG, "Date text retrieved: " + value);
        return value;
    }

}
