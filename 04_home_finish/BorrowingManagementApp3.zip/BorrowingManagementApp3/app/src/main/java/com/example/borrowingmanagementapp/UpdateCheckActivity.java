package com.example.borrowingmanagementapp;

import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.HashMap;
import java.util.Map;

/**
 * UpdateCheckActivityクラス
 * 「更新確認」画面
 */
public class UpdateCheckActivity  extends AppCompatActivity implements View.OnClickListener {

    private static final String LOG_TAG = UpdateCheckActivity.class.getSimpleName();

    @Override
    /**
     * onCreateメソッド
     * アクティビティが初めて作成されたときに呼び出される
     * @param savedInstanceState アクティビティの前回の状態を保存したバンドル
     */
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i(LOG_TAG, "onCreate called");
        // レイアウトをセット
        setContentView(R.layout.activity_update_check);
        // レイアウトの調整
        adjustLayout();
    }

    /**
     * adjustLayoutメソッド
     * レイアウトの調整を行います。
     */
    private void adjustLayout() {
        //タイトルの設定
        TextView titleTextView = findViewById(R.id.textview_update_check_title);
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("action")) {
            String action = intent.getStringExtra("action");
            if ("delete".equals(action)) {
                // deleteアクションの場合はDB削除処理を行う
                titleTextView.setText(R.string.title_delete_check);
            } else if ("update".equals(action)) {
                // updateアクションの場合はDB更新処理を行う
                titleTextView.setText(R.string.title_update_check);
            }
        }

        // 画面遷移ボタンの設定
        Button listButton = findViewById(R.id.button_update_check_cancel);
        listButton.setText(R.string.button_cancel);
        listButton.setOnClickListener(this);

        Button newInputButton = findViewById(R.id.button_update_check_confirm);
        newInputButton.setText(R.string.button_confirm);
        newInputButton.setOnClickListener(this);

        displayDataFrom();
    }

    private void displayDataFrom() {
        // TextViewを取得
        TextView dataTextView = findViewById(R.id.textview_display_data);
        // すべてのデータを取得してTextViewに表示
        StringBuilder displayTextBuilder = new StringBuilder();

        Intent intent = getIntent();
        DataObject dataObject = (DataObject) intent.getSerializableExtra("dataObject");

        displayTextBuilder.append(dataObject.getItem()).append("\n");
        displayTextBuilder.append("　").append(getString(R.string.label_serial)).append("　：　").append(dataObject.getSerial()).append("\n");
        displayTextBuilder.append("　").append(getString(R.string.label_borrower)).append("　：　").append(dataObject.getBorrower()).append("\n");
        displayTextBuilder.append("　").append(getString(R.string.label_borrow_date)).append("　：　").append(dataObject.getBorrowDate()).append("\n");
        displayTextBuilder.append("　").append(getString(R.string.label_schedule_return_date)).append("　：　").append(dataObject.getScheduleReturnDate()).append("\n");
        displayTextBuilder.append("　").append(getString(R.string.label_location)).append("　：　").append(dataObject.getLocation()).append("\n");
        displayTextBuilder.append("　").append(getString(R.string.label_returned_date)).append("　：　").append(dataObject.getReturnedDate()).append("\n");
        displayTextBuilder.append("　").append(getString(R.string.label_customer)).append("　：　").append(dataObject.getCustomer());

        // TextViewに表示
        dataTextView.setText(displayTextBuilder.toString());

    }

    @Override
    public void onClick(View v) {
        Log.d(LOG_TAG, "Button clicked with ID: " + v.getId());
        Intent intent = null;

        // クリックされたビューがnullでないかを確認
        if (v == null) {
            Log.w(LOG_TAG, "Clicked view is null");
            return;
        }
        v.getId();

        // クリックされたビューによって適切なインテントを作成
        if (v.getId() == R.id.button_update_check_confirm) {
            // 受け取ったIntentからアクションを取得
            intent = getIntent();
            if (intent != null && intent.hasExtra("action")) {
                String action = intent.getStringExtra("action");

                if ("delete".equals(action)) {
                    // deleteアクションの場合はDB削除処理を行う
                    try {
                        deleteData();
                    } catch (Exception e) {
                        Log.e(LOG_TAG, "Failed to delete data : " + e.getMessage());
                        Toast.makeText(getApplicationContext(), R.string.warning_db_delete_failed, Toast.LENGTH_LONG).show();

                        finish();
                        return;
                    }
                    Toast.makeText(this, R.string.toast_data_deleted, Toast.LENGTH_LONG).show();
                } else if ("update".equals(action)) {
                    // updateアクションの場合はDB更新処理を行う
                    try {
                     updateDBData();
                    } catch (Exception e) {
                        Log.e(LOG_TAG, "Failed to update  : " + e.getMessage());
                        Toast.makeText(getApplicationContext(), R.string.warning_db_update_failed, Toast.LENGTH_LONG).show();

                        finish();
                        return;
                    }
                    Toast.makeText(this, R.string.toast_data_updated, Toast.LENGTH_LONG).show();
                }
            }


            Intent intent2 = new Intent(getApplicationContext(), ListActivity.class);
            startActivity(intent2);
            finish();
        } else if(v.getId() == R.id.button_update_check_cancel) {

            finish();
        }
    }

    /**
     * deleteDataメソッド
     * TemporaryStorageに保存されているデータをデータベースから削除する
     */
    private void deleteData() throws Exception {
        Intent intent = getIntent();
        DataObject dataObject = (DataObject) intent.getSerializableExtra("dataObject");

        // シリアル番号を取得
        String serial = dataObject.getSerial();

        // DBUtilのインスタンスを取得
        DBUtil dbUtil = new DBUtil(getApplicationContext());

        // データを削除
        try {
            dbUtil.deleteDBData(serial);
        } catch (Exception e) {
            Log.e(LOG_TAG, "Failed to delete data: " + e.getMessage());
            throw new Exception("Failed to delete data", e);
        }
    }



    /**
     * updateDBDataメソッド
     * TemporaryStorageに保存されているデータをデータベースで更新する
     */
    /**
     * updateDBDataメソッド
     * TemporaryStorageに保存されているデータをデータベースで更新する
     */
    private void updateDBData() throws Exception {
        try {
            Intent intent = getIntent();
            DataObject dataObject = (DataObject) intent.getSerializableExtra("dataObject");

            // 新しいデータをDataObjectにセット
            DataObject newDataObject = dataObject;

            // DBUtilのインスタンスを取得
            DBUtil dbUtil = new DBUtil(this);

            // データを更新
            dbUtil.updateDBData(newDataObject);
        } catch (Exception e) {
            // 例外をキャッチしてログに出力
            Log.e(LOG_TAG, "Failed to update database data: " + e.getMessage());
            // 例外をスロー
            throw new Exception("Failed to update database data", e);
        }
    }

}
