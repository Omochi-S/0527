package com.example.borrowingmanagementapp;
//TODO:完成
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.borrowingmanagementapp.view.InputTextView;

/**
 * MainActivityクラス
 * 「借用物管理」画面
 * アプリのメイン画面を表示
 */
public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private static final String LOG_TAG = MainActivity.class.getSimpleName();

    @Override
    /**
     * onCreateメソッド
     * アクティビティが初めて作成されたときに呼び出される
     * @param savedInstanceState アクティビティの前回の状態を保存したバンドル
     */
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i(LOG_TAG, "onCreate called");
        // レイアウトをセット
        setContentView(R.layout.activity_main);
        // レイアウトの調整
        adjustLayout();
    }

    @Override
    /**
     * onClickメソッド
     * ボタンがクリックされたときに呼び出される
     * @param v クリックされたビュー
     */
    public void onClick(View v) {
        Log.d(LOG_TAG, "Button clicked with ID: " + v.getId());
        Intent intent = null;

        // クリックされたビューがnullでないかを確認
        if (v == null) {
            Log.w(LOG_TAG, "Clicked view is null");
            return;
        }

        // クリックされたビューによって適切なインテントを作成
        if (v.getId() == R.id.button_main_to_list) {
            intent = new Intent(getApplicationContext(), ListActivity.class);
            Log.i(LOG_TAG, "Navigating to ListActivity");
        } else if (v.getId() == R.id.button_main_to_new_input) {
            intent = new Intent(getApplicationContext(), NewInputActivity.class);
            Log.i(LOG_TAG, "Navigating to NewInputActivity");
        }

        // インテントがnullでない場合は、アクティビティを起動
        if(intent != null) {
            startActivity(intent);
        } else {
            Log.e(LOG_TAG, "Intent is null for view ID: " + v.getId());
        }
    }

    /**
     * adjustLayoutメソッド
     * レイアウトの調整を行います。
     */
    private void adjustLayout() {
        //タイトルの設定
        TextView titleTextView = findViewById(R.id.textview_main_title);
        titleTextView.setText(R.string.title_main);

        // 画面遷移ボタンの設定
        Button listButton = findViewById(R.id.button_main_to_list);
        listButton.setText(R.string.button_list);
        listButton.setOnClickListener(this);

        Button newInputButton = findViewById(R.id.button_main_to_new_input);
        newInputButton.setText(R.string.button_new);
        newInputButton.setOnClickListener(this);
    }
}
