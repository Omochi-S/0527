package com.example.borrowingmanagementapp;

import android.content.Intent;
import android.database.SQLException;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.HashMap;
import java.util.Map;

/**
 * NewCheckActivityクラス
 * 「新規借用確認」画面
 */
public class NewCheckActivity  extends AppCompatActivity implements View.OnClickListener {

    private static final String LOG_TAG = NewCheckActivity.class.getSimpleName();

    @Override
    /**
     * onCreateメソッド
     * アクティビティが初めて作成されたときに呼び出される
     * @param savedInstanceState アクティビティの前回の状態を保存したバンドル
     */
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i(LOG_TAG, "onCreate called");
        // レイアウトをセット
        setContentView(R.layout.activity_new_check);
        // レイアウトの調整
        adjustLayout();
    }

    /**
     * adjustLayoutメソッド
     * レイアウトの調整を行います。
     */
    private void adjustLayout() {
        //タイトルの設定
        TextView titleTextView = findViewById(R.id.textview_new_check_title);
        titleTextView.setText(R.string.title_new_check);

        // 画面遷移ボタンの設定
        Button listButton = findViewById(R.id.button_new_check_cancel);
        listButton.setText(R.string.button_cancel);
        listButton.setOnClickListener(this);

        Button newInputButton = findViewById(R.id.button_new_check_confirm);
        newInputButton.setText(R.string.button_confirm);
        newInputButton.setOnClickListener(this);

        displayDataFrom();
    }


    private void displayDataFrom() {
        // TextViewを取得
        TextView dataTextView = findViewById(R.id.textview_display_data);
        // すべてのデータを取得してTextViewに表示
        StringBuilder displayTextBuilder = new StringBuilder();

        Intent intent = getIntent();
        DataObject dataObject = (DataObject) intent.getSerializableExtra("dataObject");

        displayTextBuilder.append(dataObject.getItem()).append("\n");
        displayTextBuilder.append("　").append(getString(R.string.label_serial)).append("　：　").append(dataObject.getSerial()).append("\n");
        displayTextBuilder.append("　").append(getString(R.string.label_borrower)).append("　：　").append(dataObject.getBorrower()).append("\n");
        displayTextBuilder.append("　").append(getString(R.string.label_borrow_date)).append("　：　").append(dataObject.getBorrowDate()).append("\n");
        displayTextBuilder.append("　").append(getString(R.string.label_schedule_return_date)).append("　：　").append(dataObject.getScheduleReturnDate()).append("\n");
        displayTextBuilder.append("　").append(getString(R.string.label_location)).append("　：　").append(dataObject.getLocation()).append("\n");
        displayTextBuilder.append("　").append(getString(R.string.label_returned_date)).append("　：　").append(dataObject.getReturnedDate()).append("\n");
        displayTextBuilder.append("　").append(getString(R.string.label_customer)).append("　：　").append(dataObject.getCustomer());

        // TextViewに表示
        dataTextView.setText(displayTextBuilder.toString());

    }

    @Override
/**
 * onClickメソッド
 * ボタンがクリックされたときに呼び出される
 * @param v クリックされたビュー
 */
    public void onClick(View v) {
        Log.d(LOG_TAG, "Button clicked with ID : " + v.getId());

        // クリックされたビューがnullでないかを確認
        if (v == null) {
            Log.w(LOG_TAG, "Clicked view is null");
            return;
        }

        // クリックされたビューによって適切なインテントを作成
        if (v.getId() == R.id.button_new_check_confirm) {
            try {
                // DBデータの挿入を実行
                insertDBData();
            } catch (Exception e) {
                Log.e(LOG_TAG, "Error occurred while inserting data : ", e);
                // 例外が発生した場合はトーストを表示
                Toast.makeText(this, R.string.warning_db_registration_failed, Toast.LENGTH_LONG).show();
            }
        }

        finish();
    }

    /**
     * insertDBDataメソッド
     * TemporaryStorageに保存されているデータをデータベースに追加する
     * @throws SQLException データの追加中にエラーが発生した場合
     */
    private void insertDBData() throws SQLException {
        try {
            Intent intent = getIntent();
            DataObject dataObject = (DataObject) intent.getSerializableExtra("dataObject");


            // DBOpenHelperのインスタンスを取得
            DBUtil dbUtil = new DBUtil(this);

            // 新しいDataObjectを作成
            DataObject newData = dataObject;

            // データを追加
            boolean isAdditional = dbUtil.insertDBData(newData);

            if (isAdditional) {
                Toast.makeText(this, R.string.toast_registration_complete, Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, R.string.toast_already_registered, Toast.LENGTH_LONG).show();
            }
        } catch (SQLException e) {
            // データの追加中にSQLエラーが発生した場合は、SQLExceptionをスロー
            Log.e(LOG_TAG, "Error inserting data : ", e);
            throw e;
        } catch (Exception e) {
            // 予期しないエラーが発生した場合は、Exceptionをログに記録してSQLExceptionをスロー
            Log.e(LOG_TAG, "Unexpected error inserting data : ", e);
            throw new SQLException("Error inserting data : ", e);
        }
    }

}
