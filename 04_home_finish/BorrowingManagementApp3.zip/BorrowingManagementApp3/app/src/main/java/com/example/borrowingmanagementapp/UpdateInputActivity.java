package com.example.borrowingmanagementapp;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.borrowingmanagementapp.view.InputDateView;
import com.example.borrowingmanagementapp.view.InputTextView;

import java.util.List;

/**
 * UpdateInputActivityクラス
 * 「詳細/編集」画面
 */
public class UpdateInputActivity extends AppCompatActivity  implements View.OnClickListener {
    private static final String LOG_TAG = UpdateInputActivity.class.getSimpleName();

    //入力状況
    private static final String REQUIRED = "required";
    private static final String OPTIONAL = "optional";
    private static final String INPUT_TYPE_HALF = "half";
    private static final String INPUT_TYPE_FULL = "full";
    private static final String INPUT_TYPE_INVALID = "invalid";
    private static final int VIEW_ID = 0;
    private static final int CONDITION = 1;

    private static final int INPUT_TYPE = 2;

    private static final String[][] INPUT_DATA = {
            {"input_text_update_input_item", REQUIRED, INPUT_TYPE_FULL},
            {"input_text_update_input_serial", REQUIRED, INPUT_TYPE_HALF},
            {"input_text_update_input_borrower", REQUIRED, INPUT_TYPE_FULL},
            {"input_date_update_input_borrow", REQUIRED, INPUT_TYPE_INVALID},
            {"input_date_update_input_schedule_return", REQUIRED, INPUT_TYPE_INVALID},
            {"input_text_update_input_location", REQUIRED, INPUT_TYPE_FULL},
            {"input_date_update_input_returned", OPTIONAL, INPUT_TYPE_INVALID},
            {"input_text_update_input_customer", REQUIRED, INPUT_TYPE_FULL}
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //ログを出力
        Log.i(LOG_TAG, "onCreate");
        super.onCreate(savedInstanceState);

        //レイアウトをセット
        setContentView(R.layout.activity_update_input);
        // レイアウトの調整を行う
        adjustLayout();
        //DBの値をセット
        setValue();
    }

    private void setValue() {
        Intent intent = getIntent();
        DataObject dataObject = (DataObject) intent.getSerializableExtra("dataObject");


        // シリアル番号
        String serial = dataObject.getSerial();
        Log.d(LOG_TAG, "Serial: " + serial);
        InputTextView inputTextViewSerial = findViewById(R.id.input_text_update_input_serial);
        inputTextViewSerial.setEditTextValue(serial);

        // 品名
        String item = dataObject.getItem();
        Log.d(LOG_TAG, "Item: " + item);
        InputTextView inputTextViewItem = findViewById(R.id.input_text_update_input_item);
        inputTextViewItem.setEditTextValue(item);

        // 借用者
        String borrower = dataObject.getBorrower();
        Log.d(LOG_TAG, "Borrower: " + borrower);
        InputTextView inputTextViewBorrower = findViewById(R.id.input_text_update_input_borrower);
        inputTextViewBorrower.setEditTextValue(borrower);

        // 借用日
        String borrowDate = dataObject.getBorrowDate();
        Log.d(LOG_TAG, "Borrow Date: " + borrowDate);
        InputDateView inputDateViewBorrow = findViewById(R.id.input_date_update_input_borrow);
        inputDateViewBorrow.setDateTextViewText(borrowDate);

        // 返却予定日
        String scheduleReturnDate = dataObject.getScheduleReturnDate();
        Log.d(LOG_TAG, "Schedule Return Date: " + scheduleReturnDate);
        InputDateView inputDateViewScheduleReturn = findViewById(R.id.input_date_update_input_schedule_return);
        inputDateViewScheduleReturn.setDateTextViewText(scheduleReturnDate);

        // 使用場所
        String location = dataObject.getLocation();
        Log.d(LOG_TAG, "Location: " + location);
        InputTextView inputTextViewLocation = findViewById(R.id.input_text_update_input_location);
        inputTextViewLocation.setEditTextValue(location);

        // 返却日
        String returnedDate = dataObject.getReturnedDate();
        Log.d(LOG_TAG, "Returned Date: " + returnedDate);
        InputDateView inputDateViewReturned = findViewById(R.id.input_date_update_input_returned);
        inputDateViewReturned.setDateTextViewText(returnedDate);

        // 顧客名
        String customer = dataObject.getCustomer();
        Log.d(LOG_TAG, "Customer: " + customer);
        InputTextView inputTextViewCustomer = findViewById(R.id.input_text_update_input_customer);
        inputTextViewCustomer.setEditTextValue(customer);

    }



    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    public void onClick(View v) {
        Log.d(LOG_TAG, "Button clicked with ID: " + v.getId());
        // クリックされたビューがnullでないかを確認
        if (v == null) {
            Log.w(LOG_TAG, "Clicked view is null");
            return;
        }

        // 適切なインテントを作成
        if (v.getId() == R.id.button_update_input_update) {
            // 必須項目が全て入力されているかどうかを確認
            if (areRequiredFieldsFilled()) {
                if(inputChecker()) {
                    DataObject tempData = createDataObject();
                    Intent updateIntent = new Intent(getApplicationContext(), UpdateCheckActivity.class);
                    updateIntent.putExtra("action", "update"); // updateアクションをIntentに追加
                    updateIntent.putExtra("dataObject", tempData);
                    Log.i(LOG_TAG, "Navigating to UpdateCheckActivity");
                    startActivity(updateIntent);
                } else {
                    // 必須項目が全て入力されていない場合はToastを表示して処理を中断
                    Toast.makeText(getApplicationContext(), R.string.warning_incorrect_entered, Toast.LENGTH_LONG).show();
                }
            } else {
                // 必須項目が全て入力されていない場合はToastを表示して処理を中断
                    Toast.makeText(getApplicationContext(), R.string.warning_not_entered, Toast.LENGTH_LONG).show();
            }
        } else if (v.getId() == R.id.button_update_input_delete) {
            Intent deleteIntent = new Intent(getApplicationContext(), UpdateCheckActivity.class);
            deleteIntent.putExtra("action", "delete"); // deleteアクションをIntentに追加
            Intent intent = getIntent();
            DataObject tempData = (DataObject) intent.getSerializableExtra("dataObject");
            deleteIntent.putExtra("dataObject", tempData);
            Log.i(LOG_TAG, "Navigating to UpdateCheckActivity");
            startActivity(deleteIntent);
        }
    }


    /**
     * adjustLayoutメソッド
     * レイアウトの調整
     */
    private void adjustLayout() {

        //ヘッダーの設定
        TextView titleTextView = findViewById(R.id.textview_update_input_title);
        titleTextView.setText(R.string.title_update_input);

        //シリアル番号入力不可の設定
        InputTextView inputTextViewSerial = findViewById(R.id.input_text_update_input_serial);
        inputTextViewSerial.setEnabledEditText(false);
        inputTextViewSerial.setEditTextBackgroundColor(R.color.grey);

        // 画面遷移ボタンの調整
        Button deleteButton = findViewById(R.id.button_update_input_delete);
        deleteButton.setText(R.string.button_delete);
        deleteButton.setOnClickListener(this);

        Button updateeButton = findViewById(R.id.button_update_input_update);
        updateeButton.setText(R.string.button_update);
        updateeButton.setOnClickListener(this);
    }


    /**
     * areRequiredFieldsFilledメソッド
     * 必須項目がすべて入力されているかどうかをチェック
     * @return 必須項目がすべて入力されている場合はtrue、そうでない場合はfalse
     */
    private boolean areRequiredFieldsFilled() {
        for (String[] data : INPUT_DATA) {
            if (data[CONDITION].equals(REQUIRED)) {
                // 入力項目のビューIDを取得
                int viewId = getResources().getIdentifier(data[VIEW_ID], "id", getPackageName());
                // ビューが見つからない場合はログを出力して次のループに進む
                if (viewId == 0) {
                    Log.e(LOG_TAG, "View not found for ID: " + data[VIEW_ID]);
                    continue;
                }
                // ビューを取得
                View inputView = findViewById(viewId);
                // 入力値の初期化
                String value = "";
                // ビューの種類に応じて値を取得
                if (inputView instanceof InputTextView) {
                    value = ((InputTextView) inputView).getEditTextValue();
                } else if (inputView instanceof InputDateView) {
                    value = ((InputDateView) inputView).getDateTextValue();
                }
                // 必須項目が空であればfalseを返す
                if (value.isEmpty()) {
                    return false;
                }
            }
        }
        // 必須項目が全て入力されている場合はtrueを返す
        return true;
    }


    private DataObject createDataObject() {
        InputTextView inputItem = findViewById(R.id.input_text_update_input_item);
        InputTextView inputSerial = findViewById(R.id.input_text_update_input_serial);
        InputTextView inputBorrower = findViewById(R.id.input_text_update_input_borrower);
        InputDateView inputBorrowDate = findViewById(R.id.input_date_update_input_borrow);
        InputDateView inputScheduleReturnDate = findViewById(R.id.input_date_update_input_schedule_return);
        InputTextView inputLocation = findViewById(R.id.input_text_update_input_location);
        InputDateView inputReturnedDate = findViewById(R.id.input_date_update_input_returned);
        InputTextView inputCustomer = findViewById(R.id.input_text_update_input_customer);

        // 新しいデータオブジェクトを作成
        DataObject dataObject = new DataObject();
        dataObject.setItem(inputItem.getEditTextValue());
        dataObject.setSerial(inputSerial.getEditTextValue());
        dataObject.setBorrower(inputBorrower.getEditTextValue());
        dataObject.setBorrowDate(inputBorrowDate.getDateTextValue());
        dataObject.setScheduleReturnDate(inputScheduleReturnDate.getDateTextValue());
        dataObject.setLocation(inputLocation.getEditTextValue());
        dataObject.setReturnedDate(inputReturnedDate.getDateTextValue());
        dataObject.setCustomer(inputCustomer.getEditTextValue());

        return dataObject;
    }
	
    private boolean inputChecker() {
        boolean isCorrect = true;
        for (String[] data : INPUT_DATA) {
            boolean isInputCorrect = true;
            if (data[INPUT_TYPE] == INPUT_TYPE_INVALID) {
                continue;
            }

            // 入力項目のビューIDを取得
            int viewId = getResources().getIdentifier(data[VIEW_ID], "id", getPackageName());
            // ビューが見つからない場合はログを出力して次のループに進む
            if (viewId == 0) {
                Log.e(LOG_TAG, "View not found for ID: " + data[VIEW_ID]);
                continue;
            }
            // ビューを取得
            View inputView = findViewById(viewId);
            // 入力値の初期化
            String value = "";

            if (inputView instanceof InputTextView) {
                ((InputTextView) inputView).setEditTextBackgroundColor(R.color.white);
                value = ((InputTextView) inputView).getEditTextValue();
                //半角入力
                if (data[INPUT_TYPE] == INPUT_TYPE_HALF) {
                    isInputCorrect = InputTextView.isValidInput(value, InputTextView.INPUT_TYPE_HALF_WIDTH);
                } else if (data[INPUT_TYPE] == INPUT_TYPE_FULL) {
                    isInputCorrect = InputTextView.isValidInput(value, InputTextView.INPUT_TYPE_FULL_WIDTH);
                }
                if(!(isInputCorrect)) {
                    ((InputTextView) inputView).setEditTextBackgroundColor(R.color.yellow);
                    isCorrect = false;
                }
            }
            // 取得した値をログに出力
            Log.d(LOG_TAG, inputView.getContentDescription() + " value retrieved: " + value);
        }
        return isCorrect;
    }
}
