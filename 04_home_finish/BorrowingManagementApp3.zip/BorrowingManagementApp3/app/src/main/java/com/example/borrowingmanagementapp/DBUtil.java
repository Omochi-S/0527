package com.example.borrowingmanagementapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

/**
 * DBUtil
 * データベースユーティリティクラス
 * このクラスはデータベース操作を行う
 */
public class DBUtil {
    private static final String LOG_TAG = DBUtil.class.getSimpleName();
    private DBOpenHelper dbOpenHelper;
    private Context mContext;

    /**
     * コンストラクター
     * コンテキストを設定
     * @param context コンテキスト
     */
    public DBUtil(Context context) {
        mContext = context;
    }

    /**
     * getDatabase
     * データベースを取得する
     * @return 取得したデータベース
     * @throws SQLException データベースの取得に失敗した場合
     */
    private SQLiteDatabase getDatabase() throws SQLException {
        // データベースオープンヘルパーを使用して、このコンテキストに関連付けられた読み書き可能なデータベースを取得
        dbOpenHelper = new DBOpenHelper(mContext);
        SQLiteDatabase database = null;
        try {
            // 読み書き可能なデータベースを取得
            database = dbOpenHelper.getWritableDatabase();
        } catch (SQLException e) {
            // データベースの取得に失敗した場合は、SQLExceptionをキャッチしてログにエラーメッセージを記録し、例外をスロー
            Log.e(LOG_TAG, "Failed to retrieve database : ", e);
            throw e;
        } catch (Exception e) {
            // 予期しないエラーが発生した場合は、Exceptionをキャッチしてログにエラーメッセージを記録し、例外をスロー
            Log.e(LOG_TAG, "Unexpected error occurred : ", e);
            throw new SQLException("Failed to retrieve database : ", e);
        }
        // 取得したデータベースを返す
        return database;
    }

    /**
     * createDataContentValues
     * 新しいデータオブジェクトからContentValuesオブジェクトを生成
     * @param newData 新しいデータオブジェクト
     * @return 生成されたContentValuesオブジェクト
     * @throws SQLException ContentValuesオブジェクトの生成に失敗した場合
     */
    private ContentValues createDataContentValues(DataObject newData) throws SQLException {
        // 新しいContentValuesオブジェクトを作成
        ContentValues values = new ContentValues();
        try {
            // 新しいデータオブジェクトの各フィールドをContentValuesオブジェクトに追加
            values.put(DBOpenHelper.COLUMN_ITEM, newData.getItem());
            values.put(DBOpenHelper.COLUMN_SERIAL, newData.getSerial());
            values.put(DBOpenHelper.COLUMN_BORROWER, newData.getBorrower());
            values.put(DBOpenHelper.COLUMN_BORROW_DATE, newData.getBorrowDate());
            values.put(DBOpenHelper.COLUMN_SCHEDULE_RETURN_DATE, newData.getScheduleReturnDate());
            values.put(DBOpenHelper.COLUMN_LOCATION, newData.getLocation());
            values.put(DBOpenHelper.COLUMN_RETURNED_DATE, newData.getReturnedDate());
            values.put(DBOpenHelper.COLUMN_CUSTOMER, newData.getCustomer());
        } catch (Exception e) {
            // 例外が発生した場合は、SQLExceptionをスロー
            throw new SQLException("Failed to create ContentValues", e);
        }
        // 生成されたContentValuesオブジェクトを返す
        return values;
    }

    /**
     * createDataObject
     * カーソルからデータオブジェクトを生成
     * @param cursor カーソル
     * @return 生成されたデータオブジェクト
     * @throws SQLException データオブジェクトの生成に失敗した場合
     */
    private DataObject createDataObject(Cursor cursor) throws SQLException {
        // 新しいデータオブジェクトを作成
        DataObject dataObject = new DataObject();
        try {
            // カーソルから各列の値を取得して、データオブジェクトに設定
            dataObject.setSerial(cursor.getString(cursor.getColumnIndexOrThrow(DBOpenHelper.COLUMN_SERIAL)));
            dataObject.setItem(cursor.getString(cursor.getColumnIndexOrThrow(DBOpenHelper.COLUMN_ITEM)));
            dataObject.setBorrower(cursor.getString(cursor.getColumnIndexOrThrow(DBOpenHelper.COLUMN_BORROWER)));
            dataObject.setBorrowDate(cursor.getString(cursor.getColumnIndexOrThrow(DBOpenHelper.COLUMN_BORROW_DATE)));
            dataObject.setScheduleReturnDate(cursor.getString(cursor.getColumnIndexOrThrow(DBOpenHelper.COLUMN_SCHEDULE_RETURN_DATE)));
            dataObject.setLocation(cursor.getString(cursor.getColumnIndexOrThrow(DBOpenHelper.COLUMN_LOCATION)));
            dataObject.setReturnedDate(cursor.getString(cursor.getColumnIndexOrThrow(DBOpenHelper.COLUMN_RETURNED_DATE)));
            dataObject.setCustomer(cursor.getString(cursor.getColumnIndexOrThrow(DBOpenHelper.COLUMN_CUSTOMER)));
        } catch (Exception e) {
            // 例外が発生した場合は、SQLExceptionをスロー
            throw new SQLException("Failed to create DataObject", e);
        }
        // 生成されたデータオブジェクトを返す
        return dataObject;
    }

    /**
     * getDBAllDat
     * データベースからすべてのデータを取得
     * @return データベースから取得されたデータのリスト
     * @throws SQLException データの取得中にエラーが発生した場合
     */
    public List<DataObject> getDBAllData() throws SQLException {
        List<DataObject> dataObjects = new ArrayList<>();
        SQLiteDatabase database = null;
        Cursor cursor = null;

        try {
            // データベースを取得
            database = getDatabase();
            // データベースからクエリを実行し、カーソルを取得
            cursor = database.query(dbOpenHelper.TABLE_NAME, null, null, null, null, null, null);
            // カーソルが有効で、最初の行に移動できる場合
            if (cursor != null && cursor.moveToFirst()) {
                do {
                    // カーソルからデータオブジェクトを作成
                    DataObject dataObject = createDataObject(cursor);
                    // データオブジェクトがnullでない場合はリストに追加
                    if (dataObject != null) {
                        dataObjects.add(dataObject);
                    }
                } while (cursor.moveToNext());
            }
        } catch (SQLException e) {
            // データの取得中にSQLエラーが発生した場合は、SQLExceptionをスロー
            Log.e(LOG_TAG, "Error occurred while retrieving data : ", e);
            throw e;
        } catch (Exception e) {
            // 予期しないエラーが発生した場合は、Exceptionをログに記録
            Log.e(LOG_TAG, "Unexpected error occurred while retrieving data : ", e);
            throw new SQLException("Error occurred while retrieving data : ", e);
        } finally {
            // カーソルとデータベースをクローズ
            if (cursor != null) {
                cursor.close();
            }
            if (database != null) {
                database.close();
            }
        }
        // 取得されたデータのリストを返す
        return dataObjects;
    }

    /**
     * getDBData
     * 指定されたシリアル番号に対応するデータをデータベースから取得
     * @param serial 取得するデータのシリアル番号
     * @return データベースから取得されたデータのオブジェクト
     * @throws SQLException データの取得中にエラーが発生した場合
     */
    public DataObject getDBData(String serial) throws SQLException {
        SQLiteDatabase database = null;
        Cursor cursor = null;
        DataObject dataObject = null;

        try {
            // データベースを取得
            database = getDatabase();
            String[] columns = {
                    DBOpenHelper.COLUMN_SERIAL,
                    DBOpenHelper.COLUMN_ITEM,
                    DBOpenHelper.COLUMN_BORROWER,
                    DBOpenHelper.COLUMN_BORROW_DATE,
                    DBOpenHelper.COLUMN_SCHEDULE_RETURN_DATE,
                    DBOpenHelper.COLUMN_LOCATION,
                    DBOpenHelper.COLUMN_RETURNED_DATE,
                    DBOpenHelper.COLUMN_CUSTOMER
            };
            String selection = DBOpenHelper.COLUMN_SERIAL + " = ?";
            String[] selectionArgs = {serial};

            // データベースから指定されたシリアル番号に対応するデータをクエリしてカーソルを取得
            cursor = database.query(DBOpenHelper.TABLE_NAME, columns, selection, selectionArgs, null, null, null);

            // カーソルが有効で、最初の行に移動できる場合
            if (cursor != null && cursor.moveToFirst()) {
                // カーソルからデータオブジェクトを作成
                dataObject = createDataObject(cursor);
            }
        } catch (SQLException e) {
            // データの取得中にSQLエラーが発生した場合は、SQLExceptionをスロー
            Log.e(LOG_TAG, "Error retrieving data : ", e);
            throw e;
        } catch (Exception e) {
            // 予期しないエラーが発生した場合は、Exceptionをログに記録
            Log.e(LOG_TAG, "Unexpected error retrieving data : ", e);
            throw new SQLException("Error retrieving data : ", e);
        } finally {
            // カーソルとデータベースをクローズ
            if (cursor != null) {
                cursor.close();
            }
            if (database != null) {
                database.close();
            }
        }

        // 取得されたデータのオブジェクトを返す
        return dataObject;
    }

    /**
     * updateDBData
     * 指定されたシリアル番号に対応するデータを新しいデータで更新
     * @param serial  更新するデータのシリアル番号
     * @param newData 新しいデータ
     * @throws SQLException データの更新中にエラーが発生した場合
     */
    public void updateDBData(DataObject newData) throws SQLException {
        SQLiteDatabase database = null;

        try {
            database = getDatabase();

            // 新しいデータをContentValuesにセット
            ContentValues values = createDataContentValues(newData);

            // データを更新
            database.update(DBOpenHelper.TABLE_NAME, values, DBOpenHelper.COLUMN_SERIAL + " = ?", new String[]{newData.getSerial()});
        } catch (SQLException e) {
            // データの更新中にSQLエラーが発生した場合は、SQLExceptionをログに記録
            Log.e(LOG_TAG, "Error updating data : ", e);
            throw e;
        } catch (Exception e) {
            // 予期しないエラーが発生した場合は、Exceptionをログに記録
            Log.e(LOG_TAG, "Unexpected error updating data : ", e);
            throw new SQLException("Error updating data : ", e);
        } finally {
            if (database != null) {
                database.close();
            }
        }
    }

    /**
     * insertDBData
     * データベースに新しいデータを挿入
     * @param newData 挿入する新しいデータ
     * @return データの挿入が成功した場合はtrue、既に登録されている場合はfalse
     * @throws SQLException データの挿入中にエラーが発生した場合
     */
    public boolean insertDBData(DataObject newData) throws SQLException {
        SQLiteDatabase database = null;
        boolean isInserted = false;

        try {
            database = getDatabase();
            if (isAlreadyRegistered(database, newData.getSerial())) {
                isInserted = false;
                if (database != null) {
                    database.close();
                }
                return isInserted;
            }
            ContentValues values = createDataContentValues(newData);
            database.insert(DBOpenHelper.TABLE_NAME, null, values);
            isInserted = true;
        } catch (SQLException e) {
            // データの挿入中にSQLエラーが発生した場合は、SQLExceptionをログに記録
            Log.e(LOG_TAG, "Error inserting data : ", e);
            isInserted = false;
            throw e;
        } catch (Exception e) {
            // 予期しないエラーが発生した場合は、Exceptionをログに記録
            Log.e(LOG_TAG, "Unexpected error inserting data : ", e);
            isInserted = false;
            throw new SQLException("Error inserting data : ", e);
        } finally {
            if (database != null) {
                database.close();
            }
            return isInserted;
        }
    }

    /**
     * isAlreadyRegistered
     * 指定されたシリアル番号がすでにデータベースに登録されているかどうかをチェック
     * @param database データベース
     * @param serial   チェックするシリアル番号
     * @return データベースにすでに登録されている場合はtrue、それ以外の場合はfalse
     */
    private boolean isAlreadyRegistered(SQLiteDatabase database, String serial) {
        Cursor cursor = null;
        boolean isSerialAlreadyRegistered = false;
        try {
            // シリアル番号を条件にデータベースクエリを実行
            String query = "SELECT * FROM " + DBOpenHelper.TABLE_NAME + " WHERE " + DBOpenHelper.COLUMN_SERIAL + " = ?";
            cursor = database.rawQuery(query, new String[]{serial});
            // カーソルの行数が1以上であれば、データベースに既に登録されていることを示す
            isSerialAlreadyRegistered = cursor.getCount() > 0;
        } catch (SQLException e) {
            // データベースのクエリ実行中にエラーが発生した場合は、SQLExceptionをスロー
            throw new SQLException("Error executing database query", e);
        } finally {
            // カーソルをクローズ
            if (cursor != null) {
                cursor.close();
            }
            return isSerialAlreadyRegistered;
        }
    }

    /**
     * deleteDBData
     * 指定されたシリアル番号に対応するデータをデータベースから削除
     * @param serial 削除するデータのシリアル番号
     * @throws SQLException データベースの削除中にエラーが発生した場合
     */
    public void deleteDBData(String serial) throws SQLException {
        SQLiteDatabase database = null;
        try {
            // データベースを取得し、指定されたシリアル番号に対応するデータを削除
            database = getDatabase();
            database.delete(DBOpenHelper.TABLE_NAME, DBOpenHelper.COLUMN_SERIAL + " = ?", new String[]{serial});
        } catch (SQLException e) {
            // データの削除中にSQLエラーが発生した場合は、SQLExceptionをスロー
            Log.e(LOG_TAG, "Error deleting data : ", e);
            throw new SQLException("Error deleting data : ", e);
        } catch (Exception e) {
            // 予期しないエラーが発生した場合は、Exceptionをログに記録
            Log.e(LOG_TAG, "Unexpected error deleting data : ", e);
            throw new SQLException("Unexpected error deleting data : ", e);
        } finally {
            // データベースをクローズ
            if (database != null) {
                database.close();
            }
        }
    }
}
