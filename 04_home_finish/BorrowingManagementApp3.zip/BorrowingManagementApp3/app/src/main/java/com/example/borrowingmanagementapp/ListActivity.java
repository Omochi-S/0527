package com.example.borrowingmanagementapp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.borrowingmanagementapp.view.InputDateView;
import com.example.borrowingmanagementapp.view.InputTextView;

import java.util.ArrayList;
import java.util.List;

/**
 * ListActivityクラス
 * 「一覧」画面
 * データのリストを表示するためのアクティビティ。
 */
public class ListActivity extends AppCompatActivity {
    private static final String LOG_TAG = ListActivity.class.getSimpleName();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        adjustLayout();
        getDBAllData();
    }
    
    /**
     * データベースからデータを取得し、ListView に表示する。
     */
    /**
     * データベースからデータを取得し、ListView に表示する。
     */
    private void getDBAllData() {
        try {
            ArrayList<String> dataList = new ArrayList<>();
            ArrayList<String> serialDataList = new ArrayList<>();

            // DBUtilを使ってデータを取得
            DBUtil dbUtil = new DBUtil(getApplicationContext());
            List<DataObject> dataObjects = dbUtil.getDBAllData();

            // DataObjectリストからデータを取得してListViewに表示
            int count = 1;
            for (DataObject dataObject : dataObjects) {
                String data = count + ". " + dataObject.getItem() + "\n"
                        + "　" + getString(R.string.tag_serial) + " : " + dataObject.getSerial() + "\n"
                        + "　" + getString(R.string.tag_borrower) + " : " + dataObject.getBorrower() + "\n"
                        + "　" + getString(R.string.tag_location) + " : " + dataObject.getLocation() + "\n"
                        + "　" + getString(R.string.tag_borrow_date) + " : " + dataObject.getBorrowDate() + "\n"
                        + "　" + getString(R.string.tag_schedule_return_date) + " : " + dataObject.getScheduleReturnDate() + "\n"
                        + "　" + getString(R.string.tag_returned_date) + " : " + dataObject.getReturnedDate() + "\n"
                        + "　" + getString(R.string.tag_customer) + " : " + dataObject.getCustomer();

                dataList.add(data);
                serialDataList.add(dataObject.getSerial());
                count++;
            }

            // ListViewにデータを表示
            ListView listView = findViewById(R.id.listview_data);
            ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(this, R.layout.item_list, dataList);
            listView.setAdapter(arrayAdapter);

            // リスト項目がクリックされたときの処理
            listView.setOnItemClickListener((parent, view, position, id) -> {
                String selectedSerialItem = serialDataList.get(position);
                DataObject tempData = createDataObject(selectedSerialItem);
                Intent intent = new Intent(ListActivity.this, UpdateInputActivity.class);
                intent.putExtra("dataObject", tempData);
                startActivity(intent);
            });
       } catch (Exception e) {
            // 例外が発生した場合の処理
            Log.e(LOG_TAG, "Failed to retrieve data from database: " + e.getMessage());
            Toast.makeText(getApplicationContext(), R.string.warning_db_get_failed, Toast.LENGTH_LONG).show();
        }
    }

    private DataObject createDataObject(String serial) {
        // DBUtilを使ってデータを取得
        DBUtil dbUtil = new DBUtil(getApplicationContext());
        DataObject dataObject = dbUtil.getDBData(serial);
        return dataObject;
    }

    /**
     * レイアウトを調整する。タイトルのテキストを設定する。
     */
    private void adjustLayout() {
        TextView textView = findViewById(R.id.textview_list_title);
        textView.setText(R.string.title_list);
    }
}
